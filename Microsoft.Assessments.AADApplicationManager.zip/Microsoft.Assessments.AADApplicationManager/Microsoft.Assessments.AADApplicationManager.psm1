﻿## Script Version 3.10 - 7th Feb 2022
## Version number is in PSD1 file and needs to be updated each time a change is made here as we rely on it to update the script on customers' machines

## Constants
$scriptVersion = '3.9'
$applicationName = 'Microsoft Assessments'
$applicationNoSpace = $applicationName.Replace(" ", "")
$admin = ''
$adminPwd = ''
$Global:mfa = $false
## This version needs to be updated for any major script upgrade
$applicationVersion = 'v2'

function Test-OSVersion
{
	$v= [Version](Get-Item "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").GetValue("CurrentVersion")

	## Windows 7, 8, 2008, 2008 R2 and 2012 are NOT supported
	## Windows 8.1, 10, 2012 R2, 2016 and 2019 are supported
	if ($v.Major -lt 6 -or ($v.Major -eq 6 -and $v.Minor -lt 3))
	{
		Write-Warning "This Operating System version is not supported"
		throw [System.ApplicationException] "This Operating System version is not supported"
	}
}

function Test-OSVersionForCreate
{
	$v= [Environment]::OSVersion.Version

	## Windows 7, 8, 8.1, 2008, 2008 R2, 2012, 2012 R2 are NOT supported
	## Windows 10, 2016, 2019 are supported
	if ($v.Major -lt 10)
	{
		Write-Warning "The AAD application creation can only be done on Windows 10 or Windows Server 2016/2019 machines"
		Write-Warning "However, you can use this applicaiton on Windows 8.1 and Windows 2012 R2 machines in transferring the required settings"
		Write-Warning "using import/export functionality"

		throw [System.ApplicationException] "AAD application creation only supported on Windows 10 or Windows Server 2016/2019 machines"
	}
}

function Test-DotnetVersion
{
	$Private:latest = (Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP' -recurse | Get-ItemProperty -name Version,Release -EA 0 | Where { $_.PSChildName -match '^(?!S)\p{L}' } | % { [Version]$_.Version } | Sort-Object -Descending)[0]

	if ($Private:latest -lt "4.5")
	{
		Write-Warning 'You need to install .Net Framework 4.5'
		Write-Host 'Then rerun this script'

		throw [System.ApplicationException] "Need to install .Net 4.5"
	}

	Write-Host "Latest .Net version installed" $latest
}

function Test-Admin
{
	if (([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) -eq $false)
	{
		Write-Warning 'You need to run this script as an Administrator'
		Write-Host 'Restart this PowerShell session as Admin'

		throw [System.ApplicationException] "Need to run as Administrator"
	}
	else
	{
		Write-Host 'This script is run as an Administrator'
	}
}

function Test-PowershellGet
{
	if ((Get-Module -Name PowerShellGet -ListAvailable) -eq $null)
	{
		Write-Warning 'PowershellGet is not installed'
		Write-Host 'Please download and install "Package Management Preview", then rerun this script'
		Write-Host 'Internet Explorer will open automatically with the download page'
		Write-Warning 'IMPORTANT: You will need to restart this PowerShell session once installed'

		Start-Process "https://www.microsoft.com/en-us/download/details.aspx?id=51451"

		throw [System.ApplicationException] "Need to install Package Management Preview"
	}
	else
	{
		$Private:psgVersion = (Get-Module PowerShellGet -ListAvailable | Sort-Object { $_.Version } -Descending)[0].Version.ToString()
		Write-Host "PowerShellGet is installed - Version $Private:psgVersion"
	}
}

function Test-NugetPackageProvider
{
	$Private:nugetProvider = Get-PackageProvider -Name 'Nuget' -ErrorAction Ignore

	if ($Private:nugetProvider -eq $null)
	{
		Write-Host "Installing Nuget provider"
		Install-PackageProvider -Name Nuget -Force
		$nugetProvider = Get-PackageProvider -Name 'Nuget'
	}
	else
	{
		$Private:latestVersion = (Find-PackageProvider -Name 'Nuget').Version

		if ($Private:latestVersion -gt $Private:nugetProvider.Version)
		{
			Write-Host "Installing new Nuget provider Version" $latestVersion
			Install-PackageProvider -Name Nuget -Force
			$Private:nugetProvider = Get-PackageProvider -Name 'Nuget'
		}
	}

	Write-Host "Nuget provider installed - Version" $Private:nugetProvider.Version.ToString()
}

function Test-AzureADPreviewInstalled
{
	if ((Get-Module -Name AzureADPreview -ListAvailable) -eq $null)
	{
		Write-Host "Installing AzureADPreview PowerShell module"
		Install-Module -Name AzureADPreview -Force
	}
	else
	{
		$Private:latestVersion = (Find-Module -Name AzureADPreview).Version
		$Private:currentVersion = (Get-Module -Name AzureADPreview -ListAvailable | Sort-Object { $_.Version } -Descending)[0].Version

		if ($Private:latestVersion -gt $Private:currentVersion)
		{
			Write-Host "Updating AzureADPreview PowerShell module, new version is available" $Private:latestVersion
			Update-Module -Name AzureADPreview -Force
		}
	}

	$Private:azureADPreviewModules = Get-Module -Name AzureADPreview -ListAvailable

	if ($Private:azureADPreviewModules.Length -gt 1)
	{
		Write-Host 'More than one AzureADPreview PowerShell module is installed'
		$Private:modulesToUninstall = Get-Module AzureADPreview -ListAvailable | Sort-Object { $_.Version } -Descending | Select -Skip 1

		foreach ($module in $Private:modulesToUninstall)
		{
			Write-Host "Uninstalling AzureADPreview Module Version" $module.Version.ToString()
			Uninstall-Module -Name AzureADPreview -RequiredVersion $module.Version -Force -WarningAction Stop
		}
	}

	Write-Host "PowerShell module AzureADPreview installed - Version" (Get-Module -Name AzureADPreview -ListAvailable).Version.ToString()
}

function Test-AzureRmInstalled
{
	if ((Get-Module -Name AzureRm -ListAvailable) -eq $null)
	{
		Write-Host "Installing AzureRm PowerShell module"
		Install-Module -Name AzureRm -Force
	}
	else
	{
		$Private:latestRMVersion = (Find-Module -Name AzureRm).Version
		$Private:currentRMVersion = (Get-Module -Name AzureRm -ListAvailable | Sort-Object { $_.Version } -Descending)[0].Version

		if ($Private:latestRMVersion -gt $Private:currentRMVersion)
		{
			Write-Host "Installing AzureRm PowerShell module, new version is available" $Private:latestRMVersion
			Install-Module -Name AzureRm -Force
		}
	}

	$Private:azureRMModules = Get-Module -Name AzureRm -ListAvailable

	if ($Private:azureRMModules.Length -gt 1)
	{
		Write-Host 'More than one AzureRm PowerShell module is installed'
		$Private:rmModulesToUninstall = Get-Module AzureRm -ListAvailable | Sort-Object { $_.Version } -Descending | Select -Skip 1

		foreach ($module in $Private:rmModulesToUninstall)
		{
			Write-Host "Uninstalling AzureRm Module Version" $module.Version.ToString()
			Uninstall-Module -Name AzureRm -RequiredVersion $module.Version -Force -WarningAction Stop
		}
	}

	Write-Host "PowerShell module AzureRm installed - Version" (Get-Module -Name AzureRm -ListAvailable).Version.ToString()
}

function Test-NoAzureAD
{
	$AzAD = Get-Module -Name AzureAD -ListAvailable
	if (($AzAD -eq $null) -or ($AzAD.Length -eq 0))
	{
		Write-Host "No AzureAD PowerShell module installed (ok)"
	}
	else
	{
		Write-Host 'AzureAD PowerShell module is installed'
		$Private:modulesToUninstall = Get-Module AzureAD -ListAvailable | Sort-Object { $_.Version } -Descending

		foreach ($module in $Private:modulesToUninstall)
		{
			Write-Host "Uninstalling AzureAD Module Version" $module.Version.ToString()
			Uninstall-Module -Name AzureAD -RequiredVersion $module.Version -Force -WarningAction Stop
		}
	}
}

function Test-PowershellVersion
{
	if ($PSVersionTable.PSVersion -lt [Version]"5.1")
	{
		Write-Warning ("You need to install PowerShell version 5.1 or above, current version " + $PSVersionTable.PSVersion)
		Write-Host 'Internet Explorer will open automatically with the download page'
		Write-Warning 'IMPORTANT: You will need to restart this PowerShell session once installed'

		Start-Process "https://aka.ms/wmf5download"

		throw [System.ApplicationException] "Need to install WMF 5.1"
	}
	Write-Host "PowerShell Version" $PSVersionTable.PSVersion
}

function Test-Disconnected
{
	try
	{
		Import-Module AzureADPreview
		$aza = Split-Path (Get-Module AzureADPreview).Path
		Add-Type -Path "$aza\Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
		$Global:aadName = (Get-AzureADDomain | ? { $_.IsDefault -eq $true }).Name
		Write-Host "Disconnecting from AAD $Global:aadName"
		Disconnect-AzureAD
	}
	catch {}

	try
	{
		Import-Module AzureRm
		$t = Get-AzureRmTenant -ErrorAction Ignore

		if ($t -ne $null)
		{
			Write-Host "Disconnecting from ARM $Global:aadName"
			$x = Disconnect-AzureRmAccount
		}
	}
	catch {}
}


function Get-AADCredentials
{
	[Diagnostics.CodeAnalysis.SuppressMessage('PSAvoidUsingConvertToSecureStringWithPlainText', '', Justification='Only used for debugging')]
	param()

	if ($Global:adminCreds -eq $null -or $Global:adminCreds.Password.Length -eq 0)
	{
		if (($adminPwd -eq $null) -or ($adminPwd -eq '') -or ($admin -eq $null) -or ($admin -eq ''))
		{
			$Global:adminCreds = Get-Credential -Message "Enter your Azure tenant credentials"

			if ($Global:adminCreds -eq $null)
			{
				Write-Host "Azure credentials not provided" -ForegroundColor Red
				throw [System.ApplicationException] "Azure Credentials not provided"
			}
		}
		else
		{		
			$Global:encPwd = $adminPwd | ConvertTo-SecureString -AsPlainText -Force
			$Global:adminCreds = New-Object -TypeName "System.Management.Automation.PSCredential" -ArgumentList $admin, $encPwd	
		}
	}
}

function Connect-AzureAAD
{
	Get-AADCredentials

	$Global:aad = $null

	if ($Global:mfa -eq $true)
	{
		Write-Host "MFA is required, need to connect interactively to AAD" -ForegroundColor Yellow
		$Global:aad = Connect-AzureAD -AzureEnvironmentName $AzureEnvironment
	}
	else
	{
		try
		{
			$Global:aad = Connect-AzureAD -Credential $Global:adminCreds -AzureEnvironmentName $AzureEnvironment -ErrorAction SilentlyContinue -ErrorVariable err
		}
		catch
		{
			## MFA is required
			if (($_.Exception.Message -imatch 'AADSTS50079') -or ($_.Exception.Message -imatch 'AADSTS50076'))
			{
				$Global:mfa = $true
				Write-Host "MFA is required to connect to AAD, need to connect interactively" -ForegroundColor Yellow
				$Global:aad = Connect-AzureAD -AzureEnvironmentName $AzureEnvironment
			}
			else
			{
				$Global:adminCreds = $null
				Write-Host $_.Exception.Message -ForegroundColor Red
				throw [System.ApplicationException] "Cannot connect to AzureAD"
			}
		}
	}

	if ($Global:aad -eq $null)
	{
		Write-Host "Cannot connect to Azure AAD tenant" -ForegroundColor Red
		throw [System.ApplicationException] "Cannot connect to Azure AAD tenant"
	}

	$Global:aadName = (Get-AzureADDomain | ? { $_.IsDefault -eq $true }).Name
	$Global:TenantId = $Global:aad.TenantId

	Write-Host "Successfully connected to AAD $Global:aadName" -ForegroundColor DarkYellow
}

function Connect-AzureRmAAD
{
	Get-AADCredentials

	$azEnv = Get-PSName -Environment $Global:AzureEnvironment
	$Global:aadrm = $null
	if ($Global:mfa -eq $true)
	{
		Write-Host "MFA is required, need to connect interactively to ARM" -ForegroundColor Yellow
		$Global:aadrm = Connect-AzureRmAccount -Environment $azEnv
	}
	else
	{
		$Global:aadrm = Connect-AzureRmAccount -Credential $Global:adminCreds -Environment $azEnv -ErrorAction SilentlyContinue -ErrorVariable err

		if ($Global:aadrm -eq $null)
		{
			## MFA is required
			if (($err -imatch 'AADSTS50079') -or ($_.Exception.Message -imatch 'AADSTS50076'))
			{
				$Global:mfa = $true
				Write-Host "MFA is required to connect to ARM, need to connect interactively" -ForegroundColor Yellow
				$Global:aadrm = Connect-AzureRmAccount -Environment $azEnv
			}
			else
			{
				$Global:adminCreds = $null
				Write-Host $err -ForegroundColor Red
				throw [System.ApplicationException] "Cannot connect to AzureRM"
			}
		}
	}

	if ($Global:aadrm -eq $null)
	{
		Write-Host "Cannot connect to Azure RM tenant" -ForegroundColor Red
		throw [System.ApplicationException] "Cannot connect to Azure RM tenant"
	}

	Write-Host "Successfully connected to ARM $Global:aadName" -ForegroundColor DarkYellow
}

function Get-AzureAADApp
{
	$Private:aadApps = Get-AzureADApplication -SearchString $applicationName
	$identifierUri = "https://" + $Global:aadName + "/" + $applicationNoSpace + "/" + $applicationVersion
	$Global:ReplyUrls = "$($Global:AzurePortalUrl)/$($Global:aadName)"

	if ($Private:aadApps -eq $null)
	{
		Write-Host "Creating $applicationName AAD Application in tenant" $Global:aadName "with TenantId" $tenantId "..."

		$Global:aadApp = New-AzureADApplication -DisplayName "$applicationName" -IdentifierUris ($identifierUri) -ReplyUrls $Global:ReplyUrls
		$Global:AppId = $Global:aadApp.AppId
		Write-Host "AAD Application created - ApplicationId" $Global:aadApp.AppId
	}
	else
	{
		if ($Private:aadApps.Length -eq 1)
		{
			$Global:aadApp = $Private:aadApps[0]
			Write-Host "Found existing $applicationName AAD application - ApplicationId" $Global:aadApp.AppId

			if (($Global:aadApp.IdentifierUris)[0] -ne $identifierUri)
			{
				Write-Host "Updating AAD application identifier Uri to $applicationVersion"
				Set-AzureADApplication -Object $Global:aadApp.ObjectId -IdentifierUris ($identifierUri)
			}
		}
		else
		{
			Write-Warning "Found multiple AAD applications with name '$applicationName'"
			Write-Host 'Go to $($Global:AzurePortalUrl) > Azure Active Directory > App Registrations'
			Write-Host "Remove unneeded '$applicationName' and restart this script"

			throw [System.ApplicationException] "Multiple AAD applications"
		}
	}

	$Global:appId = $Global:aadApp.AppId
	$Global:ApplicationId = $Global:appId
}

function Get-TenantId
{
	$Global:tid = (Get-AzureADTenantDetail).ObjectId
	Write-Host "TenantID" $Global:tid
}

function Get-ServicePrincipal
{
	$Global:aadSP = Get-AzureADServicePrincipal -Filter "AppId eq '$Global:appId'"

	if ($Global:aadSP -eq $null)
	{
		Write-Host "Creating AAD Service Principal ..."
		$Global:aadSP = New-AzureADServicePrincipal -AppId $Global:appId
		Write-Host "AAD Service Principal created - ObjectId" $Global:aadSP.ObjectId
	}
	else
	{
		Write-Host "Found AAD Service Principal - ObjectId" $Global:aadSP.ObjectId
	}
}

function Find-Certficate
{
	$Global:cert = Get-ChildItem -Path "cert:\LocalMachine\My" | ? { $_.Subject -eq "CN=$applicationNoSpace.$Global:aadName" }
}

function Get-Certificate
{
	Find-Certficate

	if ($Global:cert -eq $null)
	{
		Write-Host "Creating Certificate..."

		if ((get-command New-SelfSignedCertificate).Parameters.ContainsKey("KeyExportPolicy"))
		{
			$Global:cert = New-SelfSignedCertificate -DnsName "$applicationNoSpace.$Global:aadName" -CertStoreLocation "cert:\LocalMachine\My" -KeySpec Signature -KeyExportPolicy Exportable -Provider "Microsoft Enhanced RSA and AES Cryptographic Provider" -NotAfter (Get-Date).AddYears(1)
		}
		else
		{
			## Old OS, we can't make the key exportable
			$Global:cert = New-SelfSignedCertificate -DnsName "$applicationNoSpace.$Global:aadName" -CertStoreLocation "cert:\LocalMachine\My"
		}

		Write-Host "Certificate created - Thumbprint" $Global:cert.Thumbprint "Expiration" $Global:cert.NotAfter.ToUniversalTime().ToString("u")
	}
	else
	{
		if ($Global:cert.Length -gt 1)
		{
			$Global:cert = ($Global:cert | Sort-Object { $_.NotAfter } -Descending)[0]
		}

		Write-Host "Found certificate - Thumbprint" $Global:cert.Thumbprint "Expiration" $Global:cert.NotAfter.ToUniversalTime().ToString("u")
	}
}

function Set-CertToAADApp
{
	$Global:certCred = Get-AzureADApplicationKeyCredential -ObjectId $Global:aadApp.ObjectId

	if ($Global:certCred -eq $null)
	{
		Write-Host "Creating AAD Application Key Credential..."
		$Private:KeyValue = [System.Convert]::ToBase64String($Global:cert.GetRawCertData())
		$Global:certCred = New-AzureADApplicationKeyCredential -ObjectId $Global:aadApp.ObjectId -CustomKeyIdentifier "001" -Type AsymmetricX509Cert -Usage Verify -Value $Private:KeyValue -StartDate $Global:cert.NotBefore.ToUniversalTime() -EndDate $Global:cert.NotAfter.ToUniversalTime()
		Write-Host "Created Key Credential KeyIdentifier" (-join [array]($Global:certCred.CustomKeyIdentifier | % { [char]$_ })) "EndDate" $Global:certCred.EndDate.ToUniversalTime().ToString("u")
	}
	else
	{
		$Global:certCred = ($certCred | Sort-Object EndDate -Descending)[0]
		Write-Host "Found Key Credential KeyIdentifier" (-join [array]($Global:certCred.CustomKeyIdentifier | % { [char]$_ })) "EndDate" $Global:certCred.EndDate.ToUniversalTime().ToString("u")

		if ($Global:certCred.EndDate.ToUniversalTime().AddMonths(-1) -lt [DateTime]::Now)
		{
			Write-Host "Existing cert is going to expire in the coming month, will create a new one"

			$z = ("000" + [string]([int](-join [array]($Global:certCred.CustomKeyIdentifier | % { [char]$_ }))+1))
			$NextKeyIdentifier = $z.Substring($z.Length-3, 3)

			Write-Host "Creating new certificate..."
			if ((get-command New-SelfSignedCertificate).Parameters.ContainsKey("KeyExportPolicy"))
			{
				$Global:NewCert = New-SelfSignedCertificate -DnsName "$applicationNoSpace.$Global:aadName" -CertStoreLocation "cert:\LocalMachine\My" -KeyExportPolicy Exportable -Provider "Microsoft Enhanced RSA and AES Cryptographic Provider" -NotAfter (Get-Date).AddYears(1)
			}
			else
			{
				$Global:NewCert = New-SelfSignedCertificate -DnsName "$applicationNoSpace.$Global:aadName" -CertStoreLocation "cert:\LocalMachine\My"
			}

			Write-Host "New Certificate created - Thumbprint" $Global:NewCert.Thumbprint "Expiration" $Global:NewCert.NotAfter.ToUniversalTime().ToString("u")
			$Private:KeyValue = [System.Convert]::ToBase64String($Global:NewCert.GetRawCertData())

			Write-Host "Creating new AAD Application Key Credential..."
			$Global:NewcertCred = New-AzureADApplicationKeyCredential -ObjectId $Global:aadApp.ObjectId -CustomKeyIdentifier $NextKeyIdentifier -Type AsymmetricX509Cert -Usage Verify -Value $Private:KeyValue -StartDate $Global:NewCert.NotBefore.ToUniversalTime() -EndDate $Global:NewCert.NotAfter.ToUniversalTime()

			Write-Host "Created Key Credential KeyIdentifier" (-join [array]($Global:NewcertCred.CustomKeyIdentifier | % { [char]$_ })) "EndDate" $Global:NewcertCred.EndDate.ToUniversalTime()ToString("u")

			## Removing old elements
			Write-Host "Removing old certificate and AAD Application Key credential"
			Get-ChildItem -Path "cert:\LocalMachine\My" | ? { $_.Subject -eq "CN=$applicationNoSpace.$Global:aadName" -and $_.Thumbprint -ne $Global:NewCert.Thumbprint } | Remove-Item
			Get-AzureADApplicationKeyCredential -ObjectId $Global:aadApp.ObjectId | ? { $_.KeyId -ne $Global:NewcertCred.KeyId } | % { Remove-AzureADApplicationKeyCredential -ObjectId $Global:aadApp.ObjectId -KeyId $_.KeyId }

			$Global:cert = $Global:NewCert
			$Global:certCred = $Global:NewcertCred
			$Global:NewCert = $null
			$Global:NewcertCred = $null
		}
	}

	if ([Math]::Abs((New-TimeSpan -Start ($Global:cert.NotBefore.ToUniversalTime()) -End ($Global:certCred.StartDate)).Seconds) -ge 5)
	{
		Write-Host "Mismatch between certificate and key credential. You should recreate the AAD application after cleanup" -ForegroundColor Red
		Write-Host "Local certificate   start is $($Global:cert.NotBefore.ToUniversalTime()) UTC, thumbprint $($Global:cert.thumbprint)"
		Write-Host "AAD App certificate start is $($Global:certCred.StartDate) UTC"
		throw [System.ApplicationException] "Invalid configuration"
	}
}

function Set-MSLogo
{
	$Private:MSLogo = "FFD8FFE000104A46494600010101006000600000FFDB0043000201010201010202020202020202030503030303030604040305070607070706070708090B0908080A0807070A0D0A0A0B0C0C0C0C07090E0F0D0C0E0B0C0C0CFFDB004301020202030303060303060C0807080C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0CFFC000110800D700D703012200021101031101FFC4001F0000010501010101010100000000000000000102030405060708090A0BFFC400B5100002010303020403050504040000017D01020300041105122131410613516107227114328191A1082342B1C11552D1F02433627282090A161718191A25262728292A3435363738393A434445464748494A535455565758595A636465666768696A737475767778797A838485868788898A92939495969798999AA2A3A4A5A6A7A8A9AAB2B3B4B5B6B7B8B9BAC2C3C4C5C6C7C8C9CAD2D3D4D5D6D7D8D9DAE1E2E3E4E5E6E7E8E9EAF1F2F3F4F5F6F7F8F9FAFFC4001F0100030101010101010101010000000000000102030405060708090A0BFFC400B51100020102040403040705040400010277000102031104052131061241510761711322328108144291A1B1C109233352F0156272D10A162434E125F11718191A262728292A35363738393A434445464748494A535455565758595A636465666768696A737475767778797A82838485868788898A92939495969798999AA2A3A4A5A6A7A8A9AAB2B3B4B5B6B7B8B9BAC2C3C4C5C6C7C8C9CAD2D3D4D5D6D7D8D9DAE2E3E4E5E6E7E8E9EAF2F3F4F5F6F7F8F9FAFFDA000C03010002110311003F00FDFCA28AFCC1FF0082837C7EF1E782FF006BFF0018699A3F8DBC5DA4E9B6AD69E4DA59EB17104116EB3818ED4570A32C49381C924D7CCF1571352C8F091C5D5839A94946C9A5BA6EFAFA1F67C0FC1B5B89B1D3C0D0A8A9B8C1CEED36ACA518DB4FF11FA7D457E2DFFC353FC4EFFA28DE3CFF00C1FDDFFF001CA3FE1A9FE277FD146F1E7FE0FEEFFF008E57E7FF00F119705FF40F2FBD1FAA7FC4BCE63FF4170FFC0647ED2515F8B7FF000D4FF13BFE8A378F3FF07F77FF00C728FF0086A7F89DFF00451BC79FF83FBBFF00E3947FC465C17FD03CBEF41FF12F398FFD05C3FF000191FB49457E2DFF00C353FC4EFF00A28DE3CFFC1FDDFF00F1CA3FE1A9FE277FD146F1E7FE0FEEFF00F8E51FF119705FF40F2FBD07FC4BCE63FF004170FF00C0647ED2515F8B7FF0D4FF0013BFE8A378F3FF0007F77FFC728FF86A7F89DFF451BC79FF0083FBBFFE3947FC465C17FD03CBEF41FF0012F398FF00D05C3FF0191FB49457E2DFFC353FC4EFFA28DE3CFF00C1FDDFFF001CA3FE1A9FE277FD146F1E7FE0FEEFFF008E51FF00119705FF0040F2FBD07FC4BCE63FF4170FFC0647ED2515F8FF00F077F699F891A9FC5DF0ADB5CFC40F1BDC5BDC6B16914B14BAEDD3A4A8D3202AC0BE08209041EB5FB015F71C25C5D473EA752A51A6E1C8D2D5A77BDFB7A1F9B71E700E2385EAD1A55EAC6A7B44DAB26AD66975F50A2BF3AFE36FC6DF1A693F19FC5D6B6BE2EF145B5ADB6B5791430C5AACE91C48B3B855550D8000000038005731FF000BF7C77FF43AF8B7FF0007171FFC5D7C7627C5FC1D1AB2A4F0F2F75B5BAE8EC7E472CFA9C64E3CAF43F4EE8AFCC4FF0085FBE3BFFA1D7C5BFF00838B8FFE2E8FF85FBE3BFF00A1D7C5BFF838B8FF00E2EB0FF88CB82FFA0797DE89FF005829FF00233F4EE8AFCC4FF85FBE3BFF00A1D7C5BFF838B8FF00E2E8FF0085FBE3BFFA1D7C5BFF00838B8FFE2E8FF88CB82FFA0797DE83FD60A7FC8CFD3BA2BF313FE17EF8EFFE875F16FF00E0E2E3FF008BA3FE17EF8EFF00E875F16FFE0E2E3FF8BA3FE232E0BFE81E5F7A0FF5829FF233F4EE8AFCC4FF0085FBE3BFFA1D7C5BFF00838B8FFE2E8FF85FBE3BFF00A1D7C5BFF838B8FF00E2E8FF0088CB82FF00A0797DE83FD60A7FC8CFD3BA2BF313FE17EF8EFF00E875F16FFE0E2E3FF8BAE9FE097C6DF1A6ADF19FC236B75E2EF145CDADCEB56714D0CBAACEF1CA8D3A065652D820824107820D6F86F17F075AB468AC3C97334B75D5D8A867D4E5251E57A9FA29451457EBE7BC15F927FF00052BFF0093DAF1BFFBD67FFA436F5FAD95F927FF00052BFF0093DAF1BFFBD67FFA436F5F93F8C5FF00227A5FF5F57FE9133F74FA3F7FC9435BFEBCCBFF004BA6785D14515FCDE7F60051451400514514005145140051451401D47C0FFF0092D5E0FF00FB0DD97FE8F4AFDB8AFC47F81FFF0025ABC1FF00F61BB2FF00D1E95FB715FBF7833FEED8AFF147F267F2C7D223FDEF05FE19FE713F313E3EFF00C976F1AFFD87AFBFF4A24AE4ABADF8FBFF0025DBC6BFF61EBEFF00D2892B92AFC3F34FF7DADFE297E6CFE2EADFC497AB0A28A2B84CC28A28A0028A28A0028A28A002BADF805FF25DBC15FF0061EB1FFD288EB92AEB7E017FC976F057FD87AC7FF4A23AEECAFF00DF68FF008A3F9A34A3FC48FAA3F4EE8A28AFEDA3F440AFC93FF8295FFC9ED78DFF00DEB3FF00D21B7AFD6CAFC93FF8295FFC9ED78DFF00DEB3FF00D21B7AFC9FC62FF913D2FF00AFABFF004899FBA7D1FBFE4A1ADFF5E65FFA5D33C2E8A28AFE6F3FB0028A28A0028A28A0028A28A0028A28A00EA3E07FFC96AF07FF00D86ECBFF0047A57EDC57E23FC0FF00F92D5E0FFF00B0DD97FE8F4AFDB8AFDFBC19FF0076C57F8A3F933F963E911FEF782FF0CFF389F989F1F7FE4BB78D7FEC3D7DFF00A51257255D6FC7DFF92EDE35FF00B0F5F7FE94495C957E1F9A7FBED6FF0014BF367F1756FE24BD58514515C26614514500145145001451450015D6FC02FF0092EDE0AFFB0F58FF00E94475C9575BF00BFE4BB782BFEC3D63FF00A511D77657FEFB47FC51FCD1A51FE247D51FA77451457F6D1FA2057E49FF00C14AFF00E4F6BC6FFEF59FFE90DBD7EB657E49FF00C14AFF00E4F6BC6FFEF59FFE90DBD7E4FE317FC89E97FD7D5FFA44CFDD3E8FDFF250D6FF00AF32FF00D2E99E17451457F379FD8014514500145145001451450014514500751F03FF00E4B5783FFEC3765FFA3D2BF6E2BF11FE07FF00C96AF07FFD86ECBFF47A57EDC57EFDE0CFFBB62BFC51FC99FCB1F488FF007BC17F867F9C4FCC4F8FBFF25DBC6BFF0061EBEFFD2892B92AEB7E3EFF00C976F1AFFD87AFBFF4A24AE4ABF0FCD3FDF6B7F8A5F9B3F8BAB7F125EAC28A28AE1330A28A2800A28A2800A28A2800AEB7E017FC976F057FD87AC7FF004A23AE4ABADF805FF25DBC15FF0061EB1FFD288EBBB2BFF7DA3FE28FE68D28FF00123EA8FD3BA28A2BFB68FD102BF24FFE0A57FF0027B5E37FF7ACFF00F486DEBF5B2BF24FFE0A57FF0027B5E37FF7ACFF00F486DEBF27F18BFE44F4BFEBEAFF00D2267EE9F47EFF009286B7FD7997FE974CF0BA28A2BF9BCFEC00A28A2800A28A2800A28A2800A28A2803A8F81FFF0025ABC1FF00F61BB2FF00D1E95FB715F88FF03FFE4B5783FF00EC3765FF00A3D2BF6E2BF7EF067FDDB15FE28FE4CFE58FA447FBDE0BFC33FCE27E627C7DFF0092EDE35FFB0F5F7FE94495C9575BF1F7FE4BB78D7FEC3D7DFF00A51257255F87E69FEFB5BFC52FCD9FC5D5BF892F5614514570998514514005145140051451400575BF00BFE4BB782BFEC3D63FFA511D7255D6FC02FF0092EDE0AFFB0F58FF00E94475DD95FF00BED1FF00147F346947F891F547E9DD14515FDB47E8815F927FF052BFF93DAF1BFF00BD67FF00A436F5FAD95F927FF052BFF93DAF1BFF00BD67FF00A436F5F93F8C5FF227A5FF005F57FE9133F74FA3F7FC9435BFEBCCBFF4BA6785D14515FCDE7F60051451400514514005145140051451401D47C0FF00F92D5E0FFF00B0DD97FE8F4AFDB8AFC47F81FF00F25ABC1FFF0061BB2FFD1E95FB715FBF7833FEED8AFF00147F267F2C7D223FDEF05FE19FE713F313E3EFFC976F1AFF00D87AFBFF004A24AE4ABADF8FBFF25DBC6BFF0061EBEFFD2892B92AFC3F34FF007DADFE297E6CFE2EADFC497AB0A28A2B84CC28A28A0028A28A0028A28A002BADF805FF0025DBC15FF61EB1FF00D288EB92AEB7E017FC976F057FD87AC7FF004A23AEECAFFDF68FF8A3F9A34A3FC48FAA3F4EE8A28AFEDA3F440AFCC1FF0082837C01F1E78D3F6BFF00186A7A3F827C5DAB69B74D69E4DDD9E8F713C12EDB3814ED7542A70C08383C10457E9F515F33C55C334B3CC24709566E0A3252BA49EC9AB6BEA7D9F03F19D6E19C74F1D429AA8E5070B36D2B394657D3FC27E2DFFC32CFC4EFFA273E3CFF00C27EEFFF008DD1FF000CB3F13BFE89CF8F3FF09FBBFF00E375FB49457E7FFF00106B05FF004112FB91FAA7FC4C3663FF004090FF00C0A47E2DFF00C32CFC4EFF00A273E3CFFC27EEFF00F8DD1FF0CB3F13BFE89CF8F3FF0009FBBFFE375FB49451FF00106B05FF004112FB907FC4C3663FF4090FFC0A47E2DFFC32CFC4EFFA273E3CFF00C27EEFFF008DD1FF000CB3F13BFE89CF8F3FF09FBBFF00E375FB49451FF106B05FF4112FB907FC4C3663FF004090FF00C0A47E2DFF00C32CFC4EFF00A273E3CFFC27EEFF00F8DD1FF0CB3F13BFE89CF8F3FF0009FBBFFE375FB49451FF00106B05FF004112FB907FC4C3663FF4090FFC0A47E2DFFC32CFC4EFFA273E3CFF00C27EEFFF008DD1FF000CB3F13BFE89CF8F3FF09FBBFF00E375FB49451FF106B05FF4112FB907FC4C3663FF004090FF00C0A47E3FFC1DFD99FE24699F177C2B7373F0FF00C6F6F6F6FAC5A4B2CB2E857489122CC84B3129800004927A57EC051457DC709708D1C869D4A746A39F3B4F5495AD7EDEA7E6DC79C7D88E27AB46AD7A51A7ECD34ACDBBDDA7D7D0FCEBF8DBF04BC69AB7C67F175D5AF847C51736B73AD5E4B0CD16953BC72A34EE559582E08208208E0835CC7FC282F1DFFD095E2DFF00C13DC7FF00115FA77457C7627C20C1D6AB2AAF112F79B7B2EAEE7E472C869CA4E5CCF53F313FE14178EFFE84AF16FF00E09EE3FF0088A3FE14178EFF00E84AF16FFE09EE3FF88AFD3BA2B0FF00883582FF00A0897DC89FF57E9FF3B3F313FE14178EFF00E84AF16FFE09EE3FF88A3FE14178EFFE84AF16FF00E09EE3FF0088AFD3BA28FF00883582FF00A0897DC83FD5FA7FCECFCC4FF8505E3BFF00A12BC5BFF827B8FF00E228FF008505E3BFFA12BC5BFF00827B8FFE22BF4EE8A3FE20D60BFE8225F720FF0057E9FF003B3F313FE14178EFFE84AF16FF00E09EE3FF0088A3FE14178EFF00E84AF16FFE09EE3FF88AFD3BA28FF883582FFA0897DC83FD5FA7FCECFCC4FF008505E3BFFA12BC5BFF00827B8FFE22BA7F825F04BC69A4FC67F08DD5D7847C516D6B6DAD59CB34D2E953A47122CE859998AE00001249E0015FA29456F86F0830746B46B2C449F2B4F65D1DCA86434E3252E67A0514515FAF9EF057E40FFC14EFFE4F97C75FEF597FE90DBD7EBF57E40FFC14EFFE4F97C75FEF597FE90DBD7EBDE0BFFC8EAAFF00D7A97FE9703F9CFE935FF24C61FF00EBFC7FF4DD53C168A28AFE9A3F86C28A28A0028A28A0028A28A0028A28A00EAFE047FC970F06FF00D876C7FF004A12BF736BF0CBE047FC970F06FF00D876C7FF004A12BF736BF9E7C6EFF79C2FF865F9A3FB23E8BBFEE38FFF001C3F291F11FC57FF0092A5E25FFB0ADD7FE8E6AE7EBA0F8AFF00F254BC4BFF00615BAFFD1CD5CFD7F833C45FF235C57FD7C9FF00E94CFF005372FF00F75A7FE15F920A28A2BC73AC28A28A0028A28A0028A28A002BA0F851FF00254BC35FF615B5FF00D1CB5CFD741F0A3FE4A9786BFEC2B6BFFA396BD9E1DFF91B617FEBE43FF4A472661FEEB53FC2FF00267DB9451457FAE67F2D057E40FF00C14EFF00E4F97C75FEF597FE90DBD7EBF57E40FF00C14EFF00E4F97C75FEF597FE90DBD7EBDE0BFF00C8EAAFFD7A97FE9703F9CFE935FF0024C61FFEBFC7FF004DD53C168A28AFE9A3F86C28A28A0028A28A0028A28A0028A28A00EAFE047FC970F06FFD876C7FF4A12BF736BF0CBE047FC970F06FFD876C7FF4A12BF736BF9E7C6EFF0079C2FF00865F9A3FB23E8BBFEE38FF00F1C3F291F11FC57FF92A5E25FF00B0ADD7FE8E6AE7EBA0F8AFFF00254BC4BFF615BAFF00D1CD5CFD7F833C45FF00235C57FD7C9FFE94CFF5372FFF0075A7FE15F920A28A2BC73AC28A28A0028A28A0028A28A002BA0F851FF254BC35FF00615B5FFD1CB5CFD741F0A3FE4A9786BFEC2B6BFF00A396BD9E1DFF0091B617FEBE43FF004A472661FEEB53FC2FF267DB9451457FAE67F2D057E40FFC14EFFE4F97C75FEF597FE90DBD7EBF57E40FFC14EFFE4F97C75FEF597FE90DBD7EBDE0BFFC8EAAFF00D7A97FE9703F9CFE935FF24C61FF00EBFC7FF4DD53C168A28AFE9A3F86C28A28A0028A28A0028A28A0028A28A00EAFE047FC970F06FF00D876C7FF004A12BF736BF0CBE047FC970F06FF00D876C7FF004A12BF736BF9E7C6EFF79C2FF865F9A3FB23E8BBFEE38FFF001C3F291F11FC57FF0092A5E25FFB0ADD7FE8E6AE7EBA0F8AFF00F254BC4BFF00615BAFFD1CD5CFD7F833C45FF235C57FD7C9FF00E94CFF005372FF00F75A7FE15F920A28A2BC73AC28A28A0028A28A0028A28A002BA0F851FF00254BC35FF615B5FF00D1CB5CFD741F0A3FE4A9786BFEC2B6BFFA396BD9E1DFF91B617FEBE43FF4A472661FEEB53FC2FF00267DB9451457FAE67F2D057E40FF00C14EFF00E4F97C75FEF597FE90DBD7EBF57E40FF00C14EFF00E4F97C75FEF597FE90DBD7EBDE0BFF00C8EAAFFD7A97FE9703F9CFE935FF0024C61FFEBFC7FF004DD53C168A28AFE9A3F86C28A28A0028A28A0028A28A0028A28A00EAFE047FC970F06FFD876C7FF4A12BF736BF0CBE047FC970F06FFD876C7FF4A12BF736BF9E7C6EFF0079C2FF00865F9A3FB23E8BBFEE38FF00F1C3F291F11FC57FF92A5E25FF00B0ADD7FE8E6AE7EBA0F8AFFF00254BC4BFF615BAFF00D1CD5CFD7F833C45FF00235C57FD7C9FFE94CFF5372FFF0075A7FE15F920A28A2BC73AC28A28A0028A28A0028A28A002BA0F851FF254BC35FF00615B5FFD1CB5CFD741F0A3FE4A9786BFEC2B6BFF00A396BD9E1DFF0091B617FEBE43FF004A472661FEEB53FC2FF267DB9451457FAE67F2D057E40FFC14EFFE4F97C75FEF597FE90DBD7EBF57E40FFC14EFFE4F97C75FEF597FE90DBD7EBDE0BFFC8EAAFF00D7A97FE9703F9CFE935FF24C61FF00EBFC7FF4DD53C168A28AFE9A3F86C28A28A0028A28A0028A28A0028A28A00EAFE047FC970F06FF00D876C7FF004A12BF736BF0CBE047FC970F06FF00D876C7FF004A12BF736BF9E7C6EFF79C2FF865F9A3FB23E8BBFEE38FFF001C3F291F11FC57FF0092A5E25FFB0ADD7FE8E6AE7EBA0F8AFF00F254BC4BFF00615BAFFD1CD5CFD7F833C45FF235C57FD7C9FF00E94CFF005372FF00F75A7FE15F920A28A2BC73AC28A28A0028A28A0028A28A002BA0F851FF00254BC35FF615B5FF00D1CB5CFD741F0A3FE4A9786BFEC2B6BFFA396BD9E1DFF91B617FEBE43FF4A472661FEEB53FC2FF00267DB9451457FAE67F2D057E40FF00C14EFF00E4F97C75FEF597FE90DBD7EBF57E70FEDD9FB05FC58F8CBFB5678B3C49E1BF0A7F6968BA935A9B6B9FED3B387CCD9690C6DF2C92AB0C3230E40E99E9835FA9784998617079BD5AB8BA91A7174DABCA4A2AFCD076BB6B5D1E9E47E0BF487C9F1F9970ED0A197509D69AAF16D42329B4BD9D4576A29BB5DA57DAED773E25A2BDFBFE1D79F1D3FE847FFCACE9FF00FC7E8FF875E7C74FFA11FF00F2B3A7FF00F1FAFE87FF005AF24FFA0CA5FF008321FE67F1BFFC43FE28FF00A16E23FF0004D4FF00E44F01A2BDFBFE1D79F1D3FE847FFCACE9FF00FC7E8FF875E7C74FFA11FF00F2B3A7FF00F1FA3FD6BC93FE83297FE0C87F987FC43FE28FFA16E23FF04D4FFE44F01A2BDFBFE1D79F1D3FE847FF00CACE9FFF00C7E8FF00875E7C74FF00A11FFF002B3A7FFF001FA3FD6BC93FE83297FE0C87F987FC43FE28FF00A16E23FF0004D4FF00E44F01A2BDFBFE1D79F1D3FE847FFCACE9FF00FC7E8FF875E7C74FFA11FF00F2B3A7FF00F1FA3FD6BC93FE83297FE0C87F987FC43FE28FFA16E23FF04D4FFE44F01A2BDFBFE1D79F1D3FE847FF00CACE9FFF00C7E8FF00875E7C74FF00A11FFF002B3A7FFF001FA3FD6BC93FE83297FE0C87F987FC43FE28FF00A16E23FF0004D4FF00E44F2CF811FF0025C3C1BFF61DB1FF00D284AFDCDAFCA5F84DFF0004D8F8D5E19F8A9E19D4AFBC17E4D969FAB5ADCDC49FDAF60DE5C6932333604E49C004E0026BF56ABF0AF18334C1E371186960EAC6A25195F964A56D56F66EC7F57FD1C722CCB2CC1E3639961EA5172941A5384A17B295EDCC95EDE47C47F15FFE4A97897FEC2B75FF00A39AB9FAF56F885FB38F8CF5CF1F6B97B6BA379B6B79A84F3C2FF6B8177A348CCA705C119047079AC8FF00865DF1D7FD00FF00F276DFFF008E57F8AD9F787FC535333C454A796E21A7526D3546A34D393B34F9754CFF0048F039E65B1C3D38CB110BF2AFB71EDEA7014577FF00F0CBBE3AFF00A01FFE4EDBFF00F1CA3FE1977C75FF00403FFC9DB7FF00E395E57FC43BE2BFFA16623FF0455FFE44EAFEDECB3FE8269FFE071FF3380A2BBFFF00865DF1D7FD00FF00F276DFFF008E51FF000CBBE3AFFA01FF00E4EDBFFF001CA3FE21DF15FF00D0B311FF00822AFF00F221FDBD967FD04D3FFC0E3FE67014577FFF000CBBE3AFFA01FF00E4EDBFFF001CA3FE1977C75FF403FF00C9DB7FFE3947FC43BE2BFF00A16623FF000455FF00E443FB7B2CFF00A09A7FF81C7FCCE028AEFF00FE1977C75FF403FF00C9DB7FFE3947FC32EF8EBFE807FF0093B6FF00FC728FF8877C57FF0042CC47FE08ABFF00C887F6F659FF004134FF00F038FF0099C05741F0A3FE4A9786BFEC2B6BFF00A396B7FF00E1977C75FF00403FFC9DB7FF00E395AFF0F7F671F19E87E3ED0EF6EB46F2AD6CF5082799FED7036C4591598E03927001E0735EB643E1FF001453CCF0F52A65B88515520DB746A249292BB6F97448E5C767996CB0F5231C442FCAFEDC7B7A9F53514515FEA21FCDE14514500145145001451450014514500145145001451450014514500145145001451450014514500145145001451450014514500145145007FFD9"

	$logo  = [byte[]]@()
	for ($i = 0; $i -lt $Private:MSLogo.Length ; $i += 2)
	{
		$logo += [Byte]::Parse($Private:MSLogo.Substring($i, 2), [System.Globalization.NumberStyles]::HexNumber)
	}

	$tempFile = [System.IO.Path]::GetTempFileName() + ".jpg"
	$logo | Set-Content $tempFile -Encoding Byte

	try
	{
		Write-Host "Setting MS logo for AAD application"
		Set-AzureADApplicationLogo -ObjectId $Global:aadApp.ObjectId -FilePath $tempFile
	}
	catch
	{
		Write-Host "MS logo wasn't set properly, ignoring error"
	}

	Remove-Item $tempFile -Force -ErrorAction Ignore
}

function Grant-ADAccess
{
	if ((Get-AzureADDirectoryRole | ? {$_.DisplayName -eq "Directory Readers"}) -eq $null)
	{
		Write-Host "Enabling Directory Readers role"
		Enable-AzureADDirectoryRole -RoleTemplateId (Get-AzureADDirectoryRoleTemplate | ?{$_.DisplayName -eq "Directory Readers"}).ObjectId
	}

	$Private:CurrentRole = Get-AzureADDirectoryRoleMember -ObjectId (Get-AzureADDirectoryRole | ? {$_.DisplayName -eq "Directory Readers"}).Objectid | ? { $_.AppId -eq $Global:appId }

	if ($Private:CurrentRole -eq $null)
	{
		Write-Host "Granting AAD application read-only access to AD"
		try
		{
			Add-AzureADDirectoryRoleMember -ObjectId (Get-AzureADDirectoryRole | ? {$_.DisplayName -eq "Directory Readers"}).Objectid -RefObjectId $Global:aadSP.ObjectId
		}
		catch
		{
			Write-Host $_.Exception.Message -ForegroundColor Red
		}
	}
	else
	{
		Write-Host "Read-only access to AD already granted to AAD application"
	}
}

function Grant-RBAC
{
	$Global:subscriptions = Get-AzureRmSubscription

	if (($Global:subscriptions).Count -gt 0)
	{
		$selectedSubscriptions = Select-Subscriptions

		if ($selectedSubscriptions.Count -gt 0)
		{
			foreach ($s in $selectedSubscriptions)
			{
				$sb = $Global:subscriptions | ? { $_.Id -eq $s }
				$roleAssignment = Get-AzureRmRoleAssignment -ObjectId $Global:aadSP.ObjectId -Scope "/subscriptions/$s"

				if ($roleAssignment -eq $null)
				{					
					Write-Host "Adding role assignment to subscription $($sb.Name) ($($sb.Id))"
					$nra = New-AzureRmRoleAssignment -ObjectId $Global:aadSP.ObjectId -RoleDefinitionName "Reader" -Scope "/subscriptions/$s"					
				}
				else
				{
					Write-Host "Role assignment already set for subscription $($sb.Name) ($($sb.Id))"
				}
			}
		}
		else
		{
			Write-Host "No subscription has been selected, no RBAC access will be granted"
		}
	}
	else
	{
		Write-Host "No Azure subscription found"
	}
}

function Select-Subscriptions
{
	Write-Host "Select subscriptions in the dialog box" -ForegroundColor Yellow

	$Global:cancel = $false
	[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
	[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")

	$font = New-Object System.Drawing.Font("Microsoft Sans Serif",10)

	$topLabel = New-Object System.Windows.Forms.Label
	$topLabel.Location =  New-Object System.Drawing.Point(9,9)
	$topLabel.Name = "topLabel"
	$topLabel.Size = New-Object System.Drawing.Size(471,43)
	$topLabel.TabIndex = 0
	$topLabel.Text = "Select the Azure subscriptions that you want the Microsoft Assessments application to have access to";

	$checkList = New-Object System.Windows.Forms.CheckedListBox
	$checkList.FormattingEnabled = $true
	$checkList.CheckOnClick = $true
	$Global:subscriptions | Sort-Object -Property Name | % { [void] $checkList.Items.Add("$($_.Name) ($($_.Id))")}
	$checkList.Location = New-Object System.Drawing.Point(12,55)
	$checkList.Name = "checkList"
	$checkList.Size =  New-Object System.Drawing.Size(507,109)
	$checkList.TabIndex = 5

	$cancelButton = New-Object System.Windows.Forms.Button
	$cancelButton.Font = $font
	$cancelButton.Location =  New-Object System.Drawing.Point(363,170)
	$cancelButton.Name = "cancelButton"
	$cancelButton.Size =  New-Object System.Drawing.Size(75,30)
	$cancelButton.TabIndex = 6
	$cancelButton.Text = "Cancel"
	$cancelButton.UseVisualStyleBackColor = $true
	$cancelButton.Add_Click({ $Global:cancel = $true; $form.Close(); })

	$okButton = New-Object System.Windows.Forms.Button
	$okButton.Font = $font
	$okButton.Location =  New-Object System.Drawing.Point(444,170)
	$okButton.Name = "okButton"
	$okButton.Size =  New-Object System.Drawing.Size(75,30)
	$okButton.TabIndex = 7
	$okButton.Text = "Ok"
	$okButton.UseVisualStyleBackColor = $true
	$okButton.Add_Click({ $form.Close(); })

	$selectAll = New-Object System.Windows.Forms.CheckBox
	$selectAll.AutoSize = $true
	$selectAll.Location = New-Object System.Drawing.Point(12, 170)
	$selectAll.Name = "selectAll";
	$selectAll.Size = New-Object System.Drawing.Size(101, 17)
	$selectAll.TabIndex = 8
	$selectAll.Text = "All Subscriptions"
	$selectAll.UseVisualStyleBackColor = $true
	$selectAll.Add_Click({
		$state = "Unchecked"
		if ($selectAll.Checked)
		{
			$state = "Checked"
		}
		for ($i = 0; $i -lt $checkList.Items.Count; $i++)
		{
			$checkList.SetItemCheckState($i, $state)
		}
	})

	# Set the size of your form
	$form = New-Object System.Windows.Forms.Form
	$form.SuspendLayout()
	$form.AutoScaleDimensions =  New-Object System.Drawing.SizeF(6,13)
	$form.AutoScaleMode = "Font"
	$form.ClientSize =  New-Object System.Drawing.Size(531,205)
	$form.Controls.Add($okButton)
	$form.Controls.Add($cancelButton)
	$form.Controls.Add($checkList)
	$form.Controls.Add($topLabel)
	$form.Controls.Add($selectAll)
	$form.FormBorderStyle = "FixedDialog"
	$form.Name = "Form1"
	$form.Text = "Azure Subscriptions"
	$form.TopMost = $true
	$form.ResumeLayout()

	$form.Activate()
	[void] $form.ShowDialog()

	if ($Global:cancel -eq $true)
	{
		Write-Host "You clicked on Cancel button, no subscription will be selected"
		return @();
	}

	$sx = @()
	$checkList.CheckedItems | % { [void]($_ -imatch '\(([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\)$'); $sx += $Matches[1]; }

	return $sx;
}

function Grant-GraphAccess
{
	$roles = @(
		"AccessReview.Read.All",
		"AdministrativeUnit.Read.All",
		"AuditLog.Read.All",
		"Directory.Read.All",
		"Group.Read.All",
		"IdentityProvider.Read.All",
		"IdentityRiskEvent.Read.All",
		"IdentityRiskyUser.Read.All",
		"IdentityUserFlow.Read.All",
		"Organization.Read.All",
		"Policy.Read.All",
		"PrivilegedAccess.Read.AzureAD",
		"PrivilegedAccess.Read.AzureADGroup",
		"PrivilegedAccess.Read.AzureResources",
		"Report.Read.All",
		"Reports.Read.All",
		"RoleManagement.Read.Directory",
		"SecurityActions.Read.All",
		"SecurityEvents.Read.All",
		"Sites.Read.All",
		"TermStore.Read.All",
		"TrustFrameworkKeySet.Read.All",
		"User.Read.All"
	)

	$graphId = '00000003-0000-0000-c000-000000000000'

	Write-Host "Getting Graph application"
	$graph = Get-AzureADServicePrincipal -SearchString "Microsoft Graph" | ? {$_.AppId -eq $graphId }
	$graphRoles = $graph.AppRoles | ? { $roles -contains $_.Value }

	Write-Host "Getting current application resource access"
	$reqs = (Get-AzureADApplication -ObjectId $Global:aadApp.ObjectId).RequiredResourceAccess

	$req = $reqs | ? { $_.ResourceAppId -eq $graphId }

	if ($req -eq $null)
	{
		$req = New-Object -TypeName "Microsoft.Open.AzureAD.Model.RequiredResourceAccess"
		$req.ResourceAppId = $graph.AppId
	}
	else
	{
		$nul = $reqs.Remove($req)
	}

	$accesses = @()

	foreach ($role in $graphRoles)
	{
		$access = New-Object -TypeName "Microsoft.Open.AzureAD.Model.ResourceAccess" -ArgumentList $role.Id,"Role"
		$accesses += $access
	}
	$req.ResourceAccess = $accesses

	$nul = $reqs.Add($req)

	Write-Host "Assigning Graph roles to AAD application"
	Set-AzureADApplication -ObjectId $Global:aadApp.ObjectId -RequiredResourceAccess $reqs
}

function Grant-SharePointAccess
{
	$roles2 = @(
		"Sites.Read.All",
		"TermStore.Read.All",
		"User.Read.All"
	)

	$spID = '00000003-0000-0ff1-ce00-000000000000'

	Write-Host "Getting Office 365 SharePoint application"
	$o365SP = Get-AzureADServicePrincipal -SearchString "Office 365 SharePoint" | ? {$_.AppId -eq $spID }
	$o365SPRoles = $o365SP.AppRoles | ? { $roles2 -contains $_.Value }

	Write-Host "Getting current application resource access"
	$reqs = (Get-AzureADApplication -ObjectId $Global:aadApp.ObjectId).RequiredResourceAccess

	$req = $reqs | ? { $_.ResourceAppId -eq $spID }

	if ($req -eq $null)
	{
		$req = New-Object -TypeName "Microsoft.Open.AzureAD.Model.RequiredResourceAccess"
		$req.ResourceAppId = $o365SP.AppId
	}
	else
	{
		$nul = $reqs.Remove($req)
	}

	$accesses = @()

	foreach ($role in $o365SPRoles)
	{
		$access = New-Object -TypeName "Microsoft.Open.AzureAD.Model.ResourceAccess" -ArgumentList $role.Id,"Role"
		$accesses += $access
	}
	$req.ResourceAccess = $accesses

	$nul = $reqs.Add($req)

	try
	{
		Write-Host "Assigning Office 365 SharePoint roles to AAD application"
		Set-AzureADApplication -ObjectId $Global:aadApp.ObjectId -RequiredResourceAccess $reqs
	}
	catch
	{
		Write-Host $_.Exception.Message -ForegroundColor Red
		Write-Host "Failed to set SharePoint Online rights." -ForegroundColor Yellow
	}
}

function Set-RegionSpecificEndpoints
{
	param
	(
		[ValidateSet("AzureCloud", "AzureGermanCloud", "AzureUSGovernment", "AzureUSGovGCCLow", "AzureUSGovGCCHigh", "AzureUSGovDoD", "AzureChinaCloud")]
		[string]$Environment
	)

	Write-Host "Environment parameter provided: $($Environment). Resolving AzureEnvironment..."
	if ($Environment -eq "AzureUSGovernment")
	{
		$Response = Invoke-WebRequest -Uri "https://login.microsoftonline.com/$($Global:TenantId)/.well-known/openid-configuration"
		$TenantRegionScope = (ConvertFrom-Json($Response.Content)).tenant_region_scope
		if ($TenantRegionScope -eq "DOD")
		{
			$Global:AzureEnvironment = "AzureUSGovDoD"
		}
		elseif ($TenantRegionScope -eq "USG" -or $TenantRegionScope -eq "USGov")
		{
			$Global:AzureEnvironment = "AzureUSGovGCCHigh"
		}
		else
		{
			$Global:AzureEnvironment = "AzureUSGovGCCLow"
		}
	}
	else
	{
		$Global:AzureEnvironment = $Environment
	}
	Write-Host "AzureEnvironment resolved to $($Global:AzureEnvironment)"

	Write-Host "Resolving region-specific endpoints..."
	switch ($Global:AzureEnvironment)
	{
		{$_ -in "AzureCloud","AzureUSGovGCCLow"}
		{
			$Global:AADLogonUrl = "https://login.microsoftonline.com"
			$Global:GraphUrl = "https://graph.microsoft.com"
			$Global:AzurePortalUrl = "https://aad.portal.azure.com"
			break
		}
		"AzureChinaCloud"
		{
			$Global:AADLogonUrl = "https://login.chinacloudapi.cn"
			$Global:GraphUrl = "https://microsoftgraph.chinacloudapi.cn"
			$Global:AzurePortalUrl = "https://portal.azure.cn"
			break
		}
		"AzureGermanCloud"
		{
			$Global:AADLogonUrl = "https://login.microsoftonline.de"
			$Global:GraphUrl = "https://graph.microsoft.de"
			$Global:AzurePortalUrl = "https://portal.microsoftazure.de"
			break
		}
		{$_ -in "AzureUSGovGCCHigh","AzureUSGovDoD"}
		{
			$Global:AADLogonUrl = "https://login.microsoftonline.us"
			$Global:GraphUrl = "https://graph.microsoft.us"
			$Global:AzurePortalUrl = "https://portal.azure.us"
			break
		}
		default
		{
			Write-Host "Failed to resolve region-specific endpoints." -ForegroundColor Red
			throw [System.ApplicationException] "Failed to resolve region-specific endpoints."
		}
	}

	$Global:Authority = "$($Global:AADLogonUrl)/$($Global:TenantId)"

	Write-Host "Region-specific endpoints resolved to:"
	Write-Host "  AADLogonUrl: $($Global:AADLogonUrl)"
	Write-Host "  GraphUrl: $($Global:GraphUrl)"
	Write-Host "  AzurePortalUrl: $($Global:AzurePortalUrl)"
	Write-Host "  Authority: $($Global:Authority)"
}

function Get-PSName
{
	param
	(
		[ValidateSet("AzureCloud", "AzureGermanCloud", "AzureUSGovGCCLow", "AzureUSGovGCCHigh", "AzureUSGovDoD", "AzureChinaCloud")]
		[string]$Environment
	)

	switch ($Environment)
	{
		{$_ -in "AzureCloud","AzureUSGovGCCLow"}
		{
			return "AzureCloud"
		}
		"AzureChinaCloud"
		{
			return "AzureChinaCloud"
		}
		"AzureGermanCloud"
		{
			return "AzureGermanCloud"
		}
		{$_ -in "AzureUSGovGCCHigh","AzureUSGovDoD"}
		{
			return "AzureUSGovernment"
		}
		default
		{
			Write-Host "Failed to resolve Azure Environment." -ForegroundColor Red
			throw [System.ApplicationException] "Failed to resolve Azure Environment."
		}
	}
}

function Set-AdminConsent
{
	## The application isn't immediately working, we need to wait a few seconds before it is usable
	Write-Host "Waiting for the AAD application to be ready (30 seconds)..."
	Start-Sleep -Seconds 30
	$count = 0
	do
	{
		$continue = $false
		$count = $count + 1
		$authContext = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext" -ArgumentList $Global:Authority
		$cac = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.ClientAssertionCertificate" -ArgumentList $Global:ApplicationId, $cert
		$task = $authContext.AcquireTokenAsync($Global:GraphUrl, $cac)

		while (-not $task.IsCompleted)
		{
			Start-Sleep -Seconds 1
		}
		if ($task.Exception -ne $null)
		{
			Write-Host "Exception message $($task.Exception.Message)"
			Write-Host "The AAD Application is not ready yet, trying again in a couple of seconds... (retry #$($count))"
			$continue = $true
			Start-Sleep -Seconds 15
		}
	}
	until (($continue -eq $false) -or ($count -eq 5))

	if ($count -gt 4)
	{
		throw [System.ApplicationException] "The application is not ready after waiting long enough, please try again later"
	}

	Write-Host "Granting admin consent..."
	Write-Host "We are opening a browser page for you to provide the admin consent for this application." -ForegroundColor Yellow
	Write-Host "If you receive error AADSTS700016, wait a few seconds and refresh the page" -ForegroundColor Yellow
	Start-Process "$($Global:AADLogonUrl)/common/adminconsent?client_id=$($Global:AppId)&state=12345&redirect_uri=$($Global:ReplyUrls)"
}

function Set-RegistryItems
{
	if (-not (Test-Path HKLM:\Software\Microsoft\$applicationName))
	{
		$k = New-Item -Path HKLM:\Software\Microsoft -Name "$applicationName" | Out-Null
	}

	Set-ItemProperty -Path "HKLM:\Software\Microsoft\$applicationName" -Name "Thumbprint" -Value $Global:cert.Thumbprint
	Set-ItemProperty -Path "HKLM:\Software\Microsoft\$applicationName" -Name "TenantId" -Value $Global:tid
	Set-ItemProperty -Path "HKLM:\Software\Microsoft\$applicationName" -Name "TenantDomain" -Value $Global:aad.TenantDomain
	Set-ItemProperty -Path "HKLM:\Software\Microsoft\$applicationName" -Name "ApplicationId" -Value $Global:aadApp.AppId
	Set-ItemProperty -Path "HKLM:\Software\Microsoft\$applicationName" -Name "AzureEnvironment" -Value $Global:AzureEnvironment
}

function Use-AzureModules
{
	Import-Module AzureADPreview
	Import-Module AzureRm
}

function Test-Prerequisites
{
	Write-Host "Script version $scriptVersion"

	Test-Admin
	Test-PowershellVersion
	Test-DotnetVersion
	Test-PowershellGet
	Test-NugetPackageProvider
	Test-NoAzureAD
	Test-AzureADPreviewInstalled
	Test-AzureRmInstalled
	Use-AzureModules
	Test-Disconnected
}

function New-AADApplication
{
	Connect-AzureAAD
	Set-RegionSpecificEndpoints -Environment $AzureEnvironment
	Get-TenantId
	Get-AzureAADApp
	Get-ServicePrincipal
	Get-Certificate
	Set-CertToAADApp
	Set-MSLogo
	Connect-AzureRmAAD
	Grant-ADAccess
	Grant-RBAC
	Grant-GraphAccess
	Grant-SharePointAccess
	Set-RegistryItems
	Set-AdminConsent

	Write-Host
	Write-Host "Azure AD Application successfully created" -ForegroundColor Green
	Write-Host
	Write-Host "Once the admin consent has been provided, you will be redirected to the Azure AD portal" -ForegroundColor DarkCyan
	Write-Host 'You can view this new application under ''Azure Active Directory'', ''App Registrations'', ''View All Application'' and select ''Microsoft Assessments''' -ForegroundColor DarkCyan
}

function Read-Registry
{
	if (-not (Test-Path HKLM:\Software\Microsoft\$applicationName))
	{
		Write-Host "AAD Application parameters are missing in registry" -ForegroundColor Red
		throw [System.ApplicationException] "Missing AAD application registry settings"
	}

	$Global:Thumbprint = (Get-ItemProperty -Path "HKLM:\Software\Microsoft\$applicationName" -Name "Thumbprint").Thumbprint
	$Global:TenantId = (Get-ItemProperty -Path "HKLM:\Software\Microsoft\$applicationName" -Name "TenantId").TenantId
	$Global:TenantDomain = (Get-ItemProperty -Path "HKLM:\Software\Microsoft\$applicationName" -Name "TenantDomain").TenantDomain
	$Global:ApplicationId = (Get-ItemProperty -Path "HKLM:\Software\Microsoft\$applicationName" -Name "ApplicationId").ApplicationId
	$Global:AzureEnvironment = (Get-ItemProperty -Path "HKLM:\Software\Microsoft\$applicationName" -Name "AzureEnvironment").AzureEnvironment
}

function Connect-AADApplication
{
	Read-Registry
	$azEnv = Get-PSName -Environment $Global:AzureEnvironment
	$aad = Connect-AzureAD -TenantId $Global:TenantId -ApplicationId $Global:ApplicationId -CertificateThumbprint $Global:Thumbprint -AzureEnvironmentName $azEnv
	Write-Host "Successfully connected to Azure AD using AAD application" -ForegroundColor Green
	$Global:aadName = (Get-AzureADDomain | ? { $_.IsDefault -eq $true }).Name
}

function Test-Graph
{
	Read-Registry
	Set-RegionSpecificEndpoints -Environment $Global:AzureEnvironment

	$authContext = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext" -ArgumentList $Global:Authority

	$cert = Get-ChildItem cert:\LocalMachine\my | ? { $_.Thumbprint -eq $Global:Thumbprint }
	Write-Host "Found certificate - Thumbprint" $cert.Thumbprint

	if (-not $cert.HasPrivateKey)
	{
		Write-Host "Private key for Certificate is missing" -BackgroundColor Red
		throw [System.ApplicationException] "Missing private key"
	}

	$cac = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.ClientAssertionCertificate" -ArgumentList $Global:ApplicationId, $cert

	Write-Host "Getting JWT Token..."
	$task = $authContext.AcquireTokenAsync($Global:GraphUrl, $cac)
	while (-not $task.IsCompleted)
	{
		Start-Sleep -Seconds 1
	}

	if ($task.Exception -ne $null)
	{
		 $task.Exception.InnerExceptions | % { Write-Host $_.Message -ForegroundColor Red }
		 throw [System.ApplicationException] "Inner exception"
	}
	else
	{
		$authToken = $task.Result

		$requestUrl = "$($Global:GraphUrl)/v1.0/users?`$top=2"
		$authHeader = @{ 'Authorization'=$authToken.CreateAuthorizationHeader() }
		$graphResult = Invoke-Webrequest -Uri $requestUrl -Headers $AuthHeader -Method Get

		##Write-Host "AccessToken: " $authToken.AccessToken

		$t = $authToken.AccessToken.Split('.')[0]
		if ($t.Length % 4 -ne 0)
		{
			$t = $t.PadRight($t.Length + (4 - ($t.Length % 4)), "=");
		}
		$tk = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($t));

		$t = $authToken.AccessToken.Split('.')[1]
		if ($t.Length % 4 -ne 0)
		{
			$t = $t.PadRight($t.Length + (4 - ($t.Length % 4)), "=");
		}
		$tk += ' ' + [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($t));
		Write-Host "Token:" $tk

		if ($graphResult -eq $null)
		{
			Write-Host "Graph result is null, something isn't working as expected." -ForegroundColor Red
			throw [System.ApplicationException] "Graph result is null"
		}
		if ($graphResult.StatusCode -ne 200)
		{
			Write-Host "Graph call returned an unexpected status code"$graphResult.StatusCode  -ForegroundColor Red
			throw [System.ApplicationException] "Unexpected Graph call result"
		}

		Write-Host "Output" -ForegroundColor Green
		Write-Host $graphResult.Content
		Write-Host "Successfully called Graph API" -ForegroundColor Green
	}
}

function Remove-AADApplication([bool]$force)
{
	Connect-AzureAAD

	## Force is only used to remove the AAD when we've locally lost the ApplicationId
	if (-not $force)
	{
		Remove-AzureADApplication -ObjectId (Get-AzureADApplication -SearchString "Microsoft Assessments" | ? { $_.AppId -eq $Global:ApplicationId }).ObjectId
	}
	else
	{
		$app = (Get-AzureADApplication -SearchString "Microsoft Assessments")

		if ($app -eq $null)
		{
			Write-Host "Application not found"
		}
		else
		{
			Remove-AzureADApplication -ObjectId $app.ObjectId
		}
	}

	Disconnect-AzureAD
	Write-Host "Successfully removed AAD application" -ForegroundColor Green
}

function Remove-AADSettings([bool]$cleanAll, [bool]$force)
{
	if ($cleanAll)
	{
		$message = "This action will delete the AAD application, local certificate and registry settings."
	}
	else
	{
		$message = "This action will delete local certificate and registry settings. Make sure you have already exported all settings to be able to use the AAD Application on another machine."
	}

	Write-Host $message -ForegroundColor Yellow
	Write-Host "This action cannot be undone." -ForegroundColor Red
	$confirmation = Read-Host "Are you sure you want to proceed? (type yes to confirm)"

	if ($confirmation -eq 'yes')
	{
		## Force is only used to remove the AAD when we've locally lost the ApplicationId
		if (-not $force)
		{
			Read-Registry

			## Remove certificates
			Get-ChildItem cert:\LocalMachine\my | ? { $_.Subject -eq "CN=$applicationNoSpace.$Global:TenantDomain" } | Remove-Item
			Get-ChildItem cert:\CurrentUser\my | ? { $_.Subject -eq "CN=$applicationNoSpace.$Global:TenantDomain" } | Remove-Item
		}
		else
		{
			Get-ChildItem cert:\LocalMachine\my | ? { $_.Subject.StartsWith("CN=$applicationNoSpace") } | Remove-Item
			Get-ChildItem cert:\CurrentUser\my | ? { $_.Subject.StartsWith("CN=$applicationNoSpace") } | Remove-Item
		}

		## Remove Registry key
		Remove-Item -Path "HKLM:\Software\Microsoft\Microsoft Assessments" -ErrorAction Ignore

		Write-Host "Successfully removed certificate and registry keys" -ForegroundColor Green
	}
	else
	{
		Write-Host "Operation cancelled. No change has been done" -ForegroundColor Green
		throw [System.ApplicationException] "Operation cancelled"
	}
}

function Export-AADApplicationSettings
{
	Read-Registry
	Connect-AADApplication
	Find-Certficate

	if ($Global:cert -eq $null)
	{
		Write-Host "Certificate not installed on this machine." -ForegroundColor Red
		throw [System.ApplicationException] "Certificate missing"
	}
	if (-not $Global:cert.HasPrivateKey)
	{
		Write-Host "Certificate doesn't have private key." -ForegroundColor Red
		throw [System.ApplicationException] "Missing private key"
	}

	$cred = Get-Credential -UserName "EnterPasswordOnly" -Message "Please enter a password to export the certificate"
	if ($cred.Password.Length -eq 0)
	{
		Write-Host "Password cannot be empty" -ForegroundColor Red
		Write-Host "No data has been exported"

		throw [System.ApplicationException] "Invalid Password"
	}

	$certAsString = [System.BitConverter]::ToString($Global:cert.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Pkcs12, $cred.Password))

	$string = $Global:Thumbprint + "," + $Global:TenantId + "," + $Global:TenantDomain + "," + $Global:ApplicationId + "," + $Global:AzureEnvironment + "," + $certAsString
	$string | Out-File ".\AADApplicationData.txt"

	Write-Host "Certificate and AAD Application data exported successfully" -ForegroundColor Green
	Write-Host "Copy this script and AADApplicationData.txt file to another data collection machine and then run the Import command" -ForegroundColor Yellow
}

function Import-AADApplicationSettings
{
	if (-not (Test-Path ".\AADApplicationData.txt"))
	{
		Write-Host "Exported Data have not been found." -ForegroundColor Red
		Write-Host "Please copy AADApplicationData.txt in current folder" -ForegroundColor Yellow

		throw [System.ApplicationException] "Missing export file"
	}

	$cred = Get-Credential -UserName "EnterPasswordOnly" -Message "Please enter the password that was used to export the certificate"
	if ($cred.Password.Length -eq 0)
	{
		Write-Host "Password cannot be empty" -ForegroundColor Red
		Write-Host "No data has been exported"

		throw [System.ApplicationException] "Invalid Password"
	}

	$parts = (Get-Content ".\AADApplicationData.txt").Split(",")
	$certData = [byte[]]($parts[5].Split('-') | % { [System.Convert]::ToByte($_,16) })

	$cert = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($certData, $cred.Password, [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable -bor [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::MachineKeySet -bor [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::PersistKeySet)

	if ($cert.Thumbprint.ToLowerInvariant() -ne $parts[0].ToLowerInvariant())
	{
		Write-Host "There is a data mismatch, the certificate thumbprint do not match the thumbprint used by the AAD application" -ForegroundColor Red

		throw [System.ApplicationException] "Data mismatch"
	}

	Write-Host "Importing certificate" $parts[0]
	try
	{
		$store = [System.Security.Cryptography.X509Certificates.X509Store]::new([System.Security.Cryptography.X509Certificates.StoreName]::My, [System.Security.Cryptography.X509Certificates.StoreLocation]::LocalMachine)
		$store.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadWrite)
		$store.Add($cert)
	}
	finally
	{
		try
		{
			if ($store -ne $null) { $store.Dispose() }
		}
		catch
		{
		}
	}

	if (-not (Test-Path HKLM:\Software\Microsoft\$applicationName))
	{
		$k = New-Item -Path HKLM:\Software\Microsoft -Name "$applicationName" | Out-Null
	}

	Write-Host "Setting registry keys for AAD application"
	Set-ItemProperty -Path "HKLM:\Software\Microsoft\$applicationName" -Name "Thumbprint" -Value $parts[0]
	Set-ItemProperty -Path "HKLM:\Software\Microsoft\$applicationName" -Name "TenantId" -Value $parts[1]
	Set-ItemProperty -Path "HKLM:\Software\Microsoft\$applicationName" -Name "TenantDomain" -Value $parts[2]
	Set-ItemProperty -Path "HKLM:\Software\Microsoft\$applicationName" -Name "ApplicationId" -Value $parts[3]
	Set-ItemProperty -Path "HKLM:\Software\Microsoft\$applicationName" -Name "AzureEnvironment" -Value $parts[4]

	Write-Host "Certificate and AAD Application settings are successfully imported" -ForegroundColor Green
}

<#
 .Synopsis
  Validates all prerequisistes needed to create the AAD application required for Microsoft Assessments.

 .Description
  Validates all prerequisistes needed to create the AAD application required for Microsoft Assessments.
  No AAD application is created or modified, this only checks requirements.

 .Example
   # Validates all prerequisistes
   Initialize-MicrosoftAssessmentsPrerequisites
#>
function Initialize-MicrosoftAssessmentsPrerequisites
{
	try
	{
		Test-OSVersion
		Test-Prerequisites
		Write-Host "PreRequisites successfully installed" -ForegroundColor Green
	}
	catch
	{
		if ($_.Exception.GetType().ToString() -ne 'System.ApplicationException')
		{
			Write-Error -Exception $_.Exception
		}

		Write-Warning $_.InvocationInfo.PositionMessage
	}
}

<#
 .Synopsis
  Creates the AAD application required for Microsoft Assessments.

 .Description
  Creates the AAD application required for Microsoft Assessments.
  Admin credentials to access your Azure subscription or O365 tenant are required and will not be stored
  A self-signed certificate will automatically be issued or renewed
  This certificate is stored in the Local Computer store
  If the AAD Application has already been created, it will be verified and its certificate renewed if it expires within the next month

 .Example
   # Creates the AAD application
   New-MicrosoftAssessmentsApplication
#>
function New-MicrosoftAssessmentsApplication
{
	param
	(
		[ValidateSet("AzureCloud", "AzureGermanCloud", "AzureUSGovernment", "AzureChinaCloud")]
		[string]$AzureEnvironment = "AzureCloud"
	)

	try
	{
		Test-OSVersionForCreate
		Test-Prerequisites
		New-AADApplication
	}
	catch
	{
		if ($_.Exception.GetType().ToString() -ne 'System.ApplicationException')
		{
			Write-Error -Exception $_.Exception
		}

		Write-Warning $_.InvocationInfo.PositionMessage
	}
}

<#
 .Synopsis
  Connects to your Azure AD tenant using the Microsoft Assessments AAD application.

 .Description
  Connects to your Azure AD tenant using the Microsoft Assessments AAD application.
  This allows you to validate the AAD application is working as expected

 .Example
   # Connects to Azure AD using Microsoft Assessments AAD application
   Connect-MicrosoftAssessmentsApplication
#>
function Connect-MicrosoftAssessmentsApplication
{
	try
	{
		Test-OSVersion
		Test-Disconnected
		Connect-AADApplication
	}
	catch
	{
		if ($_.Exception.GetType().ToString() -ne 'System.ApplicationException')
		{
			Write-Error -Exception $_.Exception
		}

		Write-Warning $_.InvocationInfo.PositionMessage
	}
}

<#
 .Synopsis
  Executes a Graph API call under the AAD application context

 .Description
  Executes a Graph API call under the AAD application context
  It enumerates 2 Azure AD users
  This allows you to validate the AAD application is working as expected

 .Example
   # Executes a Graph API call
   Test-MicrosoftAssessmentsGraphAPI
#>
function Test-MicrosoftAssessmentsGraphAPI
{
	try
	{
		Test-OSVersion
		Test-Prerequisites
		Test-Disconnected
		Test-Graph
	}
	catch
	{
		if ($_.Exception.GetType().ToString() -ne 'System.ApplicationException')
		{
			Write-Error -Exception $_.Exception
		}

		Write-Warning $_.InvocationInfo.PositionMessage
	}
}

<#
 .Synopsis
  Removes the AAD application settings and optionally removes the AAD Application from
  your Azure tenant.

 .Description
  Removes the AAD application settings and optionally removes the AAD Application from
  your Azure tenant.
  By default, only local parameters are removed (registry and certificate)
  If CleanAll is set to True, the AAD application is also removed from your Azure tenant
  A confirmation will be asked before deleting anything.
  NOTE: any deletion is irreversible.

 .Parameter CleanAll
  When this parameter is set to $False (the default value), we remove registry settings and
  certificate from the local machine without impacting the AAD application in your Azure tenant
  When this parameter is set to $True, we the remove registry settings and certificate from the
  local machine and also remove the AAD application from your Azure tenant

 .Parameter Force
  When this parameter is set to True, we will force the deletion of local registry and
  certificate and/or AAD application from your Azure tenant without any validation

 .Example
   # Removes local settings (registry and certificate)
   Clear-MicrosoftAssessmentsApplication

 .Example
   # Removes local settings (registry and certificate) and AAD application
   Clear-MicrosoftAssessmentsApplication -IncludeAADApplication $true
#>
function Clear-MicrosoftAssessmentsApplication
{
	param
	(
		[Parameter(Mandatory=$false)]
		[bool]$IncludeAADApplication = $False,

		[Parameter(Mandatory=$false)]
		[bool]$Force = $False,

		[Parameter(Mandatory=$false)]
		[ValidateSet("AzureCloud", "AzureGermanCloud", "AzureUSGovernment", "AzureChinaCloud")]
		[string]$AzureEnvironment = "AzureCloud"
	)

	try
	{
		Test-OSVersion
		Remove-AADSettings $IncludeAADApplication $Force

		if ($IncludeAADApplication -eq $true)
		{
			Remove-AADApplication $Force
		}
	}
	catch
	{
		if ($_.Exception.GetType().ToString() -ne 'System.ApplicationException')
		{
			Write-Error -Exception $_.Exception
		}

		Write-Warning $_.InvocationInfo.PositionMessage
	}
}

<#
 .Synopsis
  Exports your settings and the AAD associated certificate to an AADApplicationData.txt file

 .Description
  Exports your settings and the AAD associated certificate to an AADApplicationData.txt file
  A password will be required to encrypt the certificate.
  This password will be required to import AADApplicationData.txt file on another machine.

 .Example
   # Exports local settings (registry and certificate)
   Export-MicrosoftAssessmentsApplicationSettings
#>
function Export-MicrosoftAssessmentsApplicationSettings
{
	try
	{
		Test-OSVersion
		Test-Prerequisites
		Export-AADApplicationSettings
	}
	catch
	{
		if ($_.Exception.GetType().ToString() -ne 'System.ApplicationException')
		{
			Write-Error -Exception $_.Exception
		}

		Write-Warning $_.InvocationInfo.PositionMessage
	}
}

<#
 .Synopsis
  Imports your settings and the AAD associated certificate from an AADApplicationData.txt file

 .Description
  Imports your settings and the AAD associated certificate from an AADApplicationData.txt file
  The password that was used to export the settings will be required.

 .Example
   # Imports local settings (registry and certificate)
   Import-MicrosoftAssessmentsApplicationSettings
#>
function Import-MicrosoftAssessmentsApplicationSettings
{
	try
	{
		Test-OSVersion
		Test-Prerequisites
		Import-AADApplicationSettings
	}
	catch
	{
		if ($_.Exception.GetType().ToString() -ne 'System.ApplicationException')
		{
			Write-Error -Exception $_.Exception
		}

		Write-Warning $_.InvocationInfo.PositionMessage
	}
}

<#
 .Synopsis
  Show the various setting of the AAD application

 .Description
  Show the various setting of the AAD application

 .Example
   # Show settings
   Show-MicrosoftAssessmentsApplicationSettings
#>
function Show-MicrosoftAssessmentsApplicationSettings
{
	try
	{
		Read-Registry

		Write-Host
		Write-Host "Tenant Id               $($Global:TenantId)"
		Write-Host "Application Id          $($Global:ApplicationId)"
		Write-Host "Certificate Thumbprint  $($Global:Thumbprint)"
		Write-Host "Domain                  $($Global:TenantDomain)"
		Write-Host "Environment             $($Global:AzureEnvironment)"
	}
	catch
	{
		if ($_.Exception.GetType().ToString() -ne 'System.ApplicationException')
		{
			Write-Error -Exception $_.Exception
		}

		Write-Warning $_.InvocationInfo.PositionMessage
	}
}
# SIG # Begin signature block
# MIIjkgYJKoZIhvcNAQcCoIIjgzCCI38CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDveYsv5r44ldNM
# cvTsCqbRo7Nytw9QwRZwZnm6Nedn/6CCDYEwggX/MIID56ADAgECAhMzAAACUosz
# qviV8znbAAAAAAJSMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjEwOTAyMTgzMjU5WhcNMjIwOTAxMTgzMjU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDQ5M+Ps/X7BNuv5B/0I6uoDwj0NJOo1KrVQqO7ggRXccklyTrWL4xMShjIou2I
# sbYnF67wXzVAq5Om4oe+LfzSDOzjcb6ms00gBo0OQaqwQ1BijyJ7NvDf80I1fW9O
# L76Kt0Wpc2zrGhzcHdb7upPrvxvSNNUvxK3sgw7YTt31410vpEp8yfBEl/hd8ZzA
# v47DCgJ5j1zm295s1RVZHNp6MoiQFVOECm4AwK2l28i+YER1JO4IplTH44uvzX9o
# RnJHaMvWzZEpozPy4jNO2DDqbcNs4zh7AWMhE1PWFVA+CHI/En5nASvCvLmuR/t8
# q4bc8XR8QIZJQSp+2U6m2ldNAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUNZJaEUGL2Guwt7ZOAu4efEYXedEw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDY3NTk3MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAFkk3
# uSxkTEBh1NtAl7BivIEsAWdgX1qZ+EdZMYbQKasY6IhSLXRMxF1B3OKdR9K/kccp
# kvNcGl8D7YyYS4mhCUMBR+VLrg3f8PUj38A9V5aiY2/Jok7WZFOAmjPRNNGnyeg7
# l0lTiThFqE+2aOs6+heegqAdelGgNJKRHLWRuhGKuLIw5lkgx9Ky+QvZrn/Ddi8u
# TIgWKp+MGG8xY6PBvvjgt9jQShlnPrZ3UY8Bvwy6rynhXBaV0V0TTL0gEx7eh/K1
# o8Miaru6s/7FyqOLeUS4vTHh9TgBL5DtxCYurXbSBVtL1Fj44+Od/6cmC9mmvrti
# yG709Y3Rd3YdJj2f3GJq7Y7KdWq0QYhatKhBeg4fxjhg0yut2g6aM1mxjNPrE48z
# 6HWCNGu9gMK5ZudldRw4a45Z06Aoktof0CqOyTErvq0YjoE4Xpa0+87T/PVUXNqf
# 7Y+qSU7+9LtLQuMYR4w3cSPjuNusvLf9gBnch5RqM7kaDtYWDgLyB42EfsxeMqwK
# WwA+TVi0HrWRqfSx2olbE56hJcEkMjOSKz3sRuupFCX3UroyYf52L+2iVTrda8XW
# esPG62Mnn3T8AuLfzeJFuAbfOSERx7IFZO92UPoXE1uEjL5skl1yTZB3MubgOA4F
# 8KoRNhviFAEST+nG8c8uIsbZeb08SeYQMqjVEmkwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVZzCCFWMCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAlKLM6r4lfM52wAAAAACUjAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg94Bwr7kg
# fCdj9Bn2fcBc2lj97+6p9pCk9Z3l+Knxo0UwQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQAfgfcUVXT9Q7r6x/x/8uxB+0bxZn2mupOBWBn9aj44
# wGBjUQv0tDigVXlEG2js9MkCSG4YRvq5By1e/SfHPzZ1yFibPw5WgSfxT7Zwn0r6
# 1fg9mIZPP8tALqgCAGDfp3TvV7N+Sac4QcEzz9DOvy/VWeLLNiDIGTifs6g/gdQt
# 9MhER8Fn72vBMjO0t+5hS4IpXUbdBW7h7M37ftY4Cu//oA9EDRnXg+irMyL2v5pg
# pn0j3Hv4pgtAmV5BuAQ9KuaNtppH6oOo0LMl95Vb7l5kKb+89X3FLWOsx6Fuok8C
# 2CzU/cDGIki7M0IZq7gR3WyQ18k0uUaey5V1U6BEI8FkoYIS8TCCEu0GCisGAQQB
# gjcDAwExghLdMIIS2QYJKoZIhvcNAQcCoIISyjCCEsYCAQMxDzANBglghkgBZQME
# AgEFADCCAVUGCyqGSIb3DQEJEAEEoIIBRASCAUAwggE8AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIKSkG/vGvwhNe85wnLF/+Bhv/nalXq+PLCDFAwX6
# mickAgZiEAPwq70YEzIwMjIwMjIzMTYwNDAwLjIwM1owBIACAfSggdSkgdEwgc4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1p
# Y3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMg
# VFNTIEVTTjowQTU2LUUzMjktNEQ0RDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZaCCDkQwggT1MIID3aADAgECAhMzAAABW3ywujRnN8GnAAAA
# AAFbMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MB4XDTIxMDExNDE5MDIxNloXDTIyMDQxMTE5MDIxNlowgc4xCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVy
# YXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjowQTU2
# LUUzMjktNEQ0RDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vydmlj
# ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMgkf6Xs9dqhesumLltn
# l6lwjiD1jh+Ipz/6j5q5CQzSnbaVuo4KiCiSpr5WtqqVlD7nT/3WX6V6vcpNQV5c
# dtVVwafNpLn3yF+fRNoUWh1Q9u8XGiSX8YzVS8q68JPFiRO4HMzMpLCaSjcfQZId
# 6CiukyLQruKnSFwdGhMxE7GCayaQ8ZDyEPHs/C2x4AAYMFsVOssSdR8jb8fzAek3
# SNlZtVKd0Kb8io+3XkQ54MvUXV9cVL1/eDdXVVBBqOhHzoJsy+c2y/s3W+gEX8Qb
# 9O/bjBkR6hIaOwEAw7Nu40/TMVfwXJ7g5R/HNXCt7c4IajNN4W+CugeysLnYbqRm
# W+kCAwEAAaOCARswggEXMB0GA1UdDgQWBBRl5y01iG23UyBdTH/15TnJmLqrLjAf
# BgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBH
# hkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNU
# aW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUF
# BzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0
# YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsG
# AQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQCnM2s7phMamc4QdVolrO1ZXRiDMUVd
# gu9/yq8g7kIVl+fklUV2Vlout6+fpOqAGnewMtwenFtagVhVJ8Hau8Nwk+IAhB0B
# 04DobNDw7v4KETARf8KN8gTH6B7RjHhreMDWg7icV0Dsoj8MIA8AirWlwf4nr8pK
# H0n2rETseBJDWc3dbU0ITJEH1RzFhGkW7IzNPQCO165Tp7NLnXp4maZzoVx8PyiO
# NO6fyDZr0yqVuh9OqWH+fPZYQ/YYFyhxy+hHWOuqYpc83Phn1vA0Ae1+Wn4bne6Z
# GjPxRI6sxsMIkdBXD0HJLyN7YfSrbOVAYwjYWOHresGZuvoEaEgDRWUrMIIGcTCC
# BFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJv
# b3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcN
# MjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIw
# DQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0
# VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEw
# RA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQe
# dGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKx
# Xf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4G
# kbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEA
# AaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7
# fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0g
# AQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYB
# BQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUA
# bQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOh
# IW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS
# +7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlK
# kVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon
# /VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOi
# PPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/
# fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCII
# YdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0
# cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7a
# KLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQ
# cdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+
# NR4Iuto229Nfj950iEkSoYIC0jCCAjsCAQEwgfyhgdSkgdEwgc4xCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBP
# cGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjow
# QTU2LUUzMjktNEQ0RDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaIjCgEBMAcGBSsOAwIaAxUACrtBbqYy0r+YGLtUaFVRW/Yh7qaggYMwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIF
# AOXAcSMwIhgPMjAyMjAyMjMxMjM4NTlaGA8yMDIyMDIyNDEyMzg1OVowdzA9Bgor
# BgEEAYRZCgQBMS8wLTAKAgUA5cBxIwIBADAKAgEAAgIiOgIB/zAHAgEAAgIRdDAK
# AgUA5cHCowIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIB
# AAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAET8JcmBJmdAubt9
# CMF1197j2frZgRNfvT4ade3cOWU5WSZPGShbIz3aD4zGu6zNgmYVhLOmO3TcZ1v3
# nufctYkd8OmWVgoPHPtzPQiplKJ3+YDUeuUtOJzsX+THHySUSrN6/ijhoqPOE9Km
# dW62jsgvUPa2U49CbfHNso6fzedXMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAFbfLC6NGc3wacAAAAAAVswDQYJYIZIAWUD
# BAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0B
# CQQxIgQgRnzxcTA1F3Rvknkz9Sk0P12OpJPckG0liCoNuX5SkhMwgfoGCyqGSIb3
# DQEJEAIvMYHqMIHnMIHkMIG9BCDJIuCpKGMRh4lCGucGPHCNJ7jq9MTbe3mQ2FtS
# ZLCFGTCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# W3ywujRnN8GnAAAAAAFbMCIEIJrdUWGtO0JwDkG0DBl/meR6NSq+j0uEphep9x7t
# Cjh8MA0GCSqGSIb3DQEBCwUABIIBAAPAda21QQCnJBKD1PcY0J4fe3U3CHdUPnn/
# yLrqkUliQ7+3lZO0Q+S/vZeZzeacbGx6kxb/c/52/rPgzhvcsfCGSCT5yzz8qFFy
# sckod0mj9WlZiarHEP/x9DSFzLWwHKCtrI//g35bJdT1c0SXtKkg6hchQjZsCo+N
# SvFdLJie6COYTxatA7QYs6d9T1rlYQY2bzkuxLlwTVgQahp7VgKHXaAaeg/jMDlv
# 2xNRG519kP+8MJAnpPlzDhEnkqw0UjwaE4UnXI1o8JeFygUEBmJcDhPZCWKRrfIW
# 0uhA+0BE0AFXaTRqTyHrTFp2RaNws9+WPuFJ6jh8G9LBY34VoLs=
# SIG # End signature block
